<html>
<head>
<style>
#displaywinner{
    font-size: 270px;
    color: red;
    font-weight: bold;
}
#tablewinner{
    width: 100%;
}
#tablewinner tr{
    text-align: center;
}
#winnertitle{
    font-size: 60px;
}
.button{
    padding: 5px;
    color: green;
    border: 1px solid red;
}
</style>
</head>
<table id="tablewinner">
<thead>
<tr>
<th>
<span id="winnertitle">

</span>
</th>
</tr>
</thead>
<tbody>
<tr>
<td>
<span id="displaywinner">
</span>
</td>
</tr>
</tbody>
</table>
<a  class="button" href="/main/getutama">Tekan untuk memulai</a>
<a  class="button" href="/main/index">Kembali Ke Halaman Utama</a>
<img src="/images/home.svg" />
</html>