<table>
<tr>
<td>
data habis
</td>
</tr><tr>
<td>
<a href="/main/index">Halaman depan</a>
</td>
</tr>
</table>