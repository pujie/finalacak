<html>
    <head>
        <style>
            #utama{
                width: 100%;
                text-align:center;
                font-size: 50px;
                color: green;
            }
        </style>
    </head>
    <body>
        <table id="utama">

            <tr>
                <td>
                    <a href="/main/gethiburan"><img src="/images/diamond.svg"></a>
                </td>
                <td>
                    <a ><img src="/images/crown.svg"></a>
                </td>
            </tr>
            <tr>
                <td>
                    <a href="/main/gethiburan">Pemenang Hiburan</a>
                </td>
                <td>
                    <a >Pemenang Utama</a>
                </td>
            </tr>                 
        </table>
    </body>
</html>